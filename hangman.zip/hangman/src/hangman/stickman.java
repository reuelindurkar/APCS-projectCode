/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Reuel Indurkar
 */
public class stickman {
    
public stickman()
{
  

    
}


public void man(ArrayList<String> inArrayList)     
{
    int numberWrong = inArrayList.size();
    
    if(numberWrong == 1)
    {
        System.out.println("O");
    }
    
    if(numberWrong == 2)
    {
        System.out.println(" O ");
        System.out.println("/|\\");
        
    }
    
    if(numberWrong == 3)
    {
        System.out.println(" O ");
        System.out.println("/|\\");
        System.out.println(" | ");
    }
    
    if(numberWrong == 4)
    {
        System.out.println(" O ");
        System.out.println("/|\\");
        System.out.println(" | ");
        System.out.println(" | ");
    }
    
    if(numberWrong == 5)
    {
        System.out.println(" O ");
        System.out.println("/|\\");
        System.out.println(" | ");
        System.out.println(" | ");
        System.out.println("/");
    }
    if(numberWrong == 6)
    {
        System.out.println(" O ");
        System.out.println("/|\\");
        System.out.println(" | ");
        System.out.println(" | ");
        System.out.println("/ \\");
    }
    
    
    
    
}




}