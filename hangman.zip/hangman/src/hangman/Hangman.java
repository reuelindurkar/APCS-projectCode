
package hangman;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Reuel Indurkar
 * Nicole Sebek
 * 2/10/2020
 * APCS
 */

public class Hangman {
    
    
    
public static String wordPicker(String[] inArray)
{
     String word;
     word = inArray[(int)(Math.random()*10)];
     return word;
        
}

public static boolean letterChecker(ArrayList<String> inArray, String inCompare)
{
    for(int j = 0 ; j<inArray.size() ; j++)
        // checks through the whole word to see if array contains the letter
        {
        //System.out.println("checked letter" + j);
            if(inCompare.equals(inArray.get(j)))
            // checks through the array to see if the guessed letter is the same as the letter
            {
                return true;
            }
        }
    return false;
}

public static String ask()
{
    String compareAsk = "";
    System.out.println("\n \nPlease guess a letter. Please do not repeat any letters.");
        Scanner input = new Scanner(System.in);
        compareAsk = input.next();
        return compareAsk;
}

public static int whereIsItLocated(String inPickedWord, String inCompare)
{
    int index;
    index = inPickedWord.indexOf(inCompare);
    
    return index;
    

}
    
public static void main(String[] args) {
    boolean play = true;
    while(play == true)
    {
    String[] wordList = {"pony", "flower", "intake", "grace","lemon","exhaust","torque","bolt", "idler","peanut"};
       // makes the parts list 
    String pickedWord = wordPicker(wordList);
        // picks a random word and stores it in a variable
        
    //System.out.println(pickedWord);

    stickman name = new stickman ();
    
    ArrayList<String> correct = new ArrayList<String>();
    ArrayList<String> incorrect = new ArrayList<String>();
    ArrayList<String> wordArrayList = new ArrayList<String>();
    ArrayList<String> dash = new ArrayList<String>();
    
    // makes three arraylists, correct, incorrect, and one to store the picked word.
    
    

    for(int i = 0 ; i< pickedWord.length() ; i++)
    {
        wordArrayList.add(pickedWord.substring(i,i+1)); 
        dash.add("-");
    }
    // adds the picked word to the array, one letter at a timej
        
    //System.out.println(wordArrayList);
    
    
    boolean isLetterFound;
    int numberGuessed = 0;
    
        String compare = "";
        int where;
        
    while(incorrect.size() < 6 && correct.size() < wordArrayList.size())
        //repeat length till body is printed
        // amount of turns
        
    {
        compare = ask();
        //numberGuessed++;
        isLetterFound = letterChecker(wordArrayList, compare);
        where = whereIsItLocated(pickedWord,compare);
                
        if(isLetterFound == true)//adds the letter to incorrect or correct list
        {
        correct.add(compare);
        dash.set(where,compare);
        System.out.println("You guessed correctly");
        }
        else if(isLetterFound == false)
        {
        incorrect.add(compare);
        System.out.println("You guessed incorrectly");
        }
        
        //System.out.println("total # of times guessed " + numberGuessed);
        System.out.println(dash);
        System.out.println("Letters you have incorrectly guessed:" + incorrect);
        
       name.man(incorrect);
    }//end of while loop for number of turns
    
    
    
    if(correct.size() == wordArrayList.size())
        System.out.println("You win.");
    else
        System.out.println("You lose.");
        
    
    
    System.out.println("T/F: Would you like to play again(True/False)");
    
    Scanner input = new Scanner(System.in);
        play = input.nextBoolean();
    
    
    
    }
    
}
}

