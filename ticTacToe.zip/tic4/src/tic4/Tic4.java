
package tic4;
import java.util.Scanner;
/**
 *
 * Reuel Indurkar
 * Nicole Sebek
 * AP Computer Science
 * 12/2/2019
 */
public class Tic4 {

    /**
     * @param args the command line arguments
     */
    
     
    
    
    
    
    public static void main(String[] args) {
        int row;
        int col;
        int turns = 0;
        String marker;
        boolean playerX = true;
        boolean playerO = false;
        String [][] ticTacToe = {{"   ","   ","   "}, {"   ","   ","   "}, {"   ","   ","   "}};
        boolean isGameOver = false;//let game run
        
        boolean playerXWon = false;
        boolean playerOWon = false;
        
        
        for(int i=0;i<ticTacToe.length ;i++)
        {
            System.out.println("-------------");
            for(int j = 0 ; j < ticTacToe[i].length ; j++)
            {
                System.out.print("|" + ticTacToe[i][j]);
            }
            System.out.print("|");
        System.out.println();
        }
        System.out.println("-------------");
    
        //for(int t=0; t<8;t++)//repeat for nine turns
        while (isGameOver == false)
        {
            if( isGameOver == false && playerX == true)//turn for player X if game is not over
                {
                    marker = "X";
                System.out.println("PLAYER X's Turn");
                    
                    System.out.println("What row would you like to place X in (0-2)");
                    Scanner input = new Scanner(System.in);
                    row = input.nextInt();
                    System.out.println("You chose row " + row + " to place X \n");
                    
                    
                    
                    System.out.println("What column would you like to place X in (0-2)");
                    col = input.nextInt();
                    System.out.println("You chose column " + col + " to place O \n" );
                    
                    
                    
                    
                    ticTacToe [row][col] = marker;
                    playerX=false;
                    playerO=true;
                    turns++;
                    
                    //print 
                    for(int i=0;i<ticTacToe.length ;i++)
                        {
                            System.out.println("-------------");
                            for(int j = 0 ; j < ticTacToe[i].length ; j++)
                                {
                                    System.out.print("|" + ticTacToe[i][j]);
                                }
                            System.out.print("|");
                            System.out.println();
                        }
                    System.out.println("-------------");
                    
                }
                
                
            else if(isGameOver == false && playerO == true)//turn for player O
            {
                    
                marker = "O";
                System.out.println("PLAYER O's Turn");

                //public static int row()
                //int row;
                System.out.println("What row would you like to place O in (0-2)");
                Scanner input = new Scanner(System.in);
                row = input.nextInt();
                System.out.println("You chose row " + row + "to place O \n");
                //return row;
                    
                
                //public static int column();
                //int col;
                System.out.println("What column would you like to O place in (0-2)");
                input = new Scanner(System.in);
                col = input.nextInt();
                System.out.println("You chose column " + col + "to place O \n" );
                //return col;
                    
                    
                    
                ticTacToe [row][col] = marker;
                playerO = false;
                playerX = true;
                turns++;    
                                        
                    //print 
                for(int i=0;i<ticTacToe.length ;i++)
                    {
                        System.out.println("-------------");
                        for(int j = 0 ; j < ticTacToe[i].length ; j++)
                            {
                             System.out.print("|" + ticTacToe[i][j]);
                            }
                        System.out.print("|");
                        System.out.println();
                    }
                System.out.println("-------------");
                    
            }
            
            /*
            //3 horizontal checks .equals
            
            if( ((ticTacToe[0][0].equals("X")) && (ticTacToe[0][1].equals("X")) && (ticTacToe[0][2].equals("X"))) ||
                    ((ticTacToe[0][0].equals("O")) && (ticTacToe[0][1].equals("O")) && (ticTacToe[0][2].equals("O")))  ){
                isGameOver = true;}
           
            if( ((ticTacToe[1][0].equals("X")) && (ticTacToe[1][1].equals("X")) && (ticTacToe[1][2].equals("X"))) ||
                    ((ticTacToe[1][0].equals("O")) && (ticTacToe[1][1].equals("O")) && (ticTacToe[1][2].equals("O")))  ){
                isGameOver = true;}
            
            if( ((ticTacToe[2][0].equals("X")) && (ticTacToe[2][1].equals("X")) && (ticTacToe[2][2].equals("X"))) ||
                    ((ticTacToe[2][0].equals("O")) && (ticTacToe[2][1].equals("O")) && (ticTacToe[2][2].equals("O")))  ){
                isGameOver = true;}
            
            // vertical checks
            
            if( ((ticTacToe[0][0].equals("X")) && (ticTacToe[1][0].equals("X")) && (ticTacToe[2][0].equals("X"))) ||
                    ((ticTacToe[0][0].equals("O")) && (ticTacToe[1][0].equals("O")) && (ticTacToe[2][0].equals("O")))  ){
                isGameOver = true;}
            
            if( ((ticTacToe[0][1].equals("X")) && (ticTacToe[1][1].equals("X")) && (ticTacToe[2][1].equals("X"))) ||
                    ((ticTacToe[0][1].equals("O")) && (ticTacToe[1][1].equals("O")) && (ticTacToe[2][1].equals("O")))  ){
                isGameOver = true;}  
            
            if( ((ticTacToe[0][2].equals("X")) && (ticTacToe[1][2].equals("X")) && (ticTacToe[2][2].equals("X"))) ||
                    ((ticTacToe[0][2].equals("O")) && (ticTacToe[1][2].equals("O")) && (ticTacToe[2][2].equals("O")))  ){
                isGameOver = true;}
             
            // diagonal checks
            
            if( ((ticTacToe[0][0].equals("X")) && (ticTacToe[1][1].equals("X")) && (ticTacToe[2][1].equals("X"))) ||
                    ((ticTacToe[0][0].equals("O")) && (ticTacToe[1][1].equals("O")) && (ticTacToe[2][2].equals("O")))  ){
                isGameOver = true;}
            
            if( ((ticTacToe[0][2].equals("X")) && (ticTacToe[1][1].equals("X")) && (ticTacToe[2][0].equals("X"))) ||
                   ((ticTacToe[0][2].equals("O")) && (ticTacToe[1][1].equals("O")) && (ticTacToe[2][0].equals("O")))  ){
                isGameOver = true;}
            */
            
            if(     ((ticTacToe[0][0].equals("X")) && (ticTacToe[1][0].equals("X")) && (ticTacToe[2][0].equals("X"))) ||//vert
                    ((ticTacToe[0][1].equals("X")) && (ticTacToe[1][1].equals("X")) && (ticTacToe[2][1].equals("X"))) ||//vert
                    ((ticTacToe[0][2].equals("X")) && (ticTacToe[1][2].equals("X")) && (ticTacToe[2][2].equals("X"))) ||//vert
                    ((ticTacToe[0][0].equals("X")) && (ticTacToe[0][1].equals("X")) && (ticTacToe[0][2].equals("X"))) ||//hor
                    ((ticTacToe[1][0].equals("X")) && (ticTacToe[1][1].equals("X")) && (ticTacToe[1][2].equals("X"))) ||//hor
                    ((ticTacToe[2][0].equals("X")) && (ticTacToe[2][1].equals("X")) && (ticTacToe[2][2].equals("X"))) ||//hor
                    ((ticTacToe[0][0].equals("X")) && (ticTacToe[1][1].equals("X")) && (ticTacToe[2][2].equals("X"))) ||//diag
                    ((ticTacToe[0][2].equals("X")) && (ticTacToe[1][1].equals("X")) && (ticTacToe[2][0].equals("X")))   //diag
                    
                    )
            { 
                isGameOver = true;
                playerXWon = true;
                System.out.println("The game is over. Player X won.");
            }
            
            if(     ((ticTacToe[0][0].equals("O")) && (ticTacToe[1][0].equals("O")) && (ticTacToe[2][0].equals("O"))) ||//vert
                    ((ticTacToe[0][1].equals("O")) && (ticTacToe[1][1].equals("O")) && (ticTacToe[2][1].equals("O"))) ||//vert
                    ((ticTacToe[0][2].equals("O")) && (ticTacToe[1][2].equals("O")) && (ticTacToe[2][2].equals("O"))) ||//vert
                    ((ticTacToe[0][0].equals("O")) && (ticTacToe[0][1].equals("O")) && (ticTacToe[0][2].equals("O"))) ||//hor
                    ((ticTacToe[1][0].equals("O")) && (ticTacToe[1][1].equals("O")) && (ticTacToe[1][2].equals("O"))) ||//hor
                    ((ticTacToe[2][0].equals("O")) && (ticTacToe[2][1].equals("O")) && (ticTacToe[2][2].equals("O"))) ||//hor
                    ((ticTacToe[0][0].equals("O")) && (ticTacToe[1][1].equals("O")) && (ticTacToe[2][2].equals("O"))) ||//diag
                    ((ticTacToe[0][2].equals("O")) && (ticTacToe[1][1].equals("O")) && (ticTacToe[2][0].equals("O")))   //diag
                    
                    )
            { 
                isGameOver = true;
                playerOWon = true;
                System.out.println("The game is over. Player O won.");
            }
            
            if((turns == 9)&&(!playerOWon)&&(!playerXWon))
            {
                isGameOver = true;
                System.out.println("The game is over. It is a Draw. Tie game. No winner.");
            }
            
            
            
            
            
        }//end of nine turns
        
        
        
        
        
        
        
        
    }
    
}



