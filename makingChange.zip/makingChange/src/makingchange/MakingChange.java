package makingchange;
import java.util.Scanner ;
/**
 *
 * @author reuel indurkar
 */
public class MakingChange {


    public static void main(String[] args) {
       
        double penny;
        double nickel;
        double dime;
        double quarter;
        int one;
        int five;
        int ten;
        
        System.out.println("What is the price of the itme that you would like to purchase? I am in training."); // set Price of item
        Scanner input = new Scanner (System.in); 
        double priceOfItem = input.nextDouble();

        System.out.println ("How much money are you giving me?"); // set how much money customer gave to cashier --> startCash
        double startCash = input.nextDouble();
        // i add .005 to fix the rounding problem that java has. 
        //System.out.println ("add 0.005"); 
        startCash += 0.005;
      //  System.out.println(startCash);

                
        double startChange = (startCash - priceOfItem);// Determine change, and set startChange to amount of change owed to the customer from the cashier
      //  System.out.println("This is start change");
       // System.out.printf("'%.2f'",startChange );  // prints how much change to give
       // System.out.println("\n");
        
        int cashMoney = (int) startChange;//determines how much cash to give
      //  System.out.println(cashMoney);
        
        double coinMoney =  startChange - cashMoney;//determines how much coins to give
      //  System.out.println(coinMoney);
        
        // the process is to divide the cash money by the bill so that we can see how many of that bill will be needed. then i mod the cash money by the bill to see how much is left becasue that is the remainder. 
        // i repeat this with every bill to take care of the cash money.
        // i multiple the coin money by 100 becasue you cant mod by decimals.
        // instead of dime = .10. i use dime = 10. becasue i need to multiply the coin values by 100 since i multiplied the coin money by 100
        // at the end i print all the coin values.
        
        
        
        ten = cashMoney/10; // set how many tens to the amount of cast divided by ten. this shoiws how many tens can fit in the cash amount
        cashMoney %= 10; // set the remainder to cash money. this shows how much money is left to give back
        //System.out.println("number of tens to give:");    
       // System.out.println(ten);
       // System.out.println("print how much cashMoney left to give back");    
       // System.out.println(cashMoney);

        five = cashMoney/5; // 
        cashMoney %= 5;
       // System.out.println("i will give you these many fives:");    
      //  System.out.println (five);
      //  System.out.println("print how much cashMoney left to give back");    
      //  System.out.println(cashMoney);
      //  
        one = cashMoney/1;
        cashMoney %= 1;
       // System.out.println("i will give you these many ones:");    
       // System.out.println (one);
       // System.out.println("print how much cashMoney left to give back");    
       // System.out.println(cashMoney);
        
        coinMoney *= 100;
        
        
        
        quarter =(int)  coinMoney/ 25 ;
        coinMoney %= 25 ;
       // System.out.println("i will give you these many quarters:");    
       // System.out.println (quarter);
       // System.out.println("print how much coinMoney left to give back");    
       // System.out.println(coinMoney);
        
        dime =(int) coinMoney/ 10 ;
        coinMoney %= 10 ;
       // System.out.println("i will give you these many dimes:");    
       // System.out.println (dime);
       // System.out.println("print how much coinMoney left to give back");    
       // System.out.println(coinMoney);
        
        nickel =(int) coinMoney/ 5 ;
        coinMoney %= 5 ;
       // System.out.println("i will give you these many nickel:");    
       // System.out.println (nickel);
        //System.out.println("print how much coinMoney left to give back");    
       // System.out.println(coinMoney);
        
        penny =(int) coinMoney/ 1 ;
        coinMoney %= 1 ;
       //System.out.println("i will give you these many penny:");    
        //System.out.println (penny);
       // System.out.println("print how much coinMoney left to give back");    
       // System.out.println(coinMoney);
        
        System.out.println("i owe you:"); 
        System.out.println(ten + " tens"); 
        System.out.println(five + " fives"); 
        System.out.println(one + " ones"); 
        System.out.println(quarter + " quarters"); 
        System.out.println(dime + " dimes"); 
        System.out.println(nickel + " nickels"); 
        System.out.println(penny + " pennies"); 
        
        
        
    }
}

