/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack2020;
import javax.swing.* ;
import java.awt.* ;
import java.util.Scanner;
import java.util.*;
/**
 *
 * @author dot
 */
public class BlackJack2020 {

    /**
     * @param args the command line arguments
     */
    
    public static void calculateHand( Player pl )
    {
        System.out.println("Player");
        int numbOfAce;
        ArrayList<Card> tempHand= pl.getHand();
        for (int i = 0 ; i < pl.getHand().size();i++)
        {
            
            //System.out.println(tempHand.get(i).getSuit());
           // System.out.println(tempHand.get(i).getName());
            if(tempHand.get(i).getSuit().equals("ace"))
            {
                tempHand.get(i).changeValue(1);
            }
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        
        
        
        JFrame frame = new GraphicOptions();
        frame.setTitle("Move with keys");
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.requestFocus();   // set the focus to JFrame to receive KeyEvent

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        Deck playingCards = new Deck();
        //System.out.println(playingCards.getDeck());
        playingCards.shuffle();
        //System.out.println(playingCards.getDeck());
        
        Player Andy = new Player();
        Player Dealer = new Player();
        Andy.addCard(playingCards.getTopCard());
           
        Dealer.addCard(playingCards.getTopCard());
        Andy.addCard(playingCards.getTopCard());
        Dealer.addCard(playingCards.getTopCard());
        System.out.println("Andy's hand: "+Andy.getHand());
        System.out.println("Andy's score: "+Andy.getScore());
        System.out.println("dealer's hand: " + Dealer.getHand());
        System.out.println("dealer's score: " +  Dealer.getScore());
       // System.out.println(playingCards.getDeck());
      //  System.out.println(Andy.getScore());
        
        Boolean hit = true;
        while(hit==true)      
        {
            System.out.println("Would Andy like another card?(True/False)");
            Scanner input = new Scanner(System.in);
            hit = input.nextBoolean();
            //System.out.println(Andy.getHand());
            if(hit)
            {
                Andy.addCard(playingCards.getTopCard());
                System.out.println("Andy's hand: "+Andy.getHand());
                System.out.println("Andy's score: "+Andy.getScore());
               
                 if(Andy.getScore() > 21)  {
                   // System.out.println("Andy GT 21.");
                    calculateHand(Andy);
                } else {
                    //System.out.println("Andy good less than 21.");
                } 
            }
            else if(!hit)
            {
                System.out.println("Andy's hand: " + Andy.getHand());
                System.out.println("Andy's score: "+Andy.getScore());
                if(Andy.getScore() > 21)  {
                    //System.out.println("Andy GT 21.");
                    calculateHand(Andy);
                } else {
                   // System.out.println("Andy good less than 21.");
                } 
            }                    
        }
        
        Boolean DealerHit = true; 
        int score = 0;
        while ((Dealer.getScore())<17)
        {
            Dealer.addCard(playingCards.getTopCard());
            System.out.println("dealer is drawing another card.");
        }
        if (Dealer.getScore() > 21) {
            //System.out.println("dealer gt 21");
            calculateHand(Dealer);
        }
        else{
           // System.out.println("dealer lt 21");
        }
            
        
        System.out.println("dealer's hand: " + Dealer.getHand());
        System.out.println("dealer's score: " +  Dealer.getScore());
        
        //win condition
        int DealerScore = Dealer.getScore();
        int AndyScore = Andy.getScore();
        
        System.out.println("andyScore" + AndyScore);
        System.out.println("Dealer score"+ DealerScore);
        
        if(DealerScore>21)
        {
            System.out.println("Andy Wins.");
        }
        else if(DealerScore<AndyScore)
        {
            System.out.println("Andy Wins.");
        }
        else if(AndyScore>21)
        {
            System.out.println("Dealer wins.");
        }
        else if (DealerScore>AndyScore)
        {
            System.out.println("Dealer wins.");
        }
        else if(DealerScore==AndyScore)
        {
            System.out.println("Tie game.");
        }
       
       }
}

