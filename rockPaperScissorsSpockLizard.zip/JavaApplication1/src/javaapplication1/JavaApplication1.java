
package javaapplication1;
// Reuel Indurkar
// Nicole Sebek
// APCS oct 7,2019
import java.util.Scanner;
public class JavaApplication1 {

    public static int computersChoice(int start, int range)
    {
       return (int)(start + Math.random()* range);
    }
    
            
    public static void main(String[] args) {
        int cw = 0;
        int uw = 0; 
        int start = 1;
        int range = 5;
        
        
        for(int repeat = 1; repeat <= 7; repeat++)//repeat this 7 times
        {
        int cc = computersChoice(start, range); //computer choice 1-5
        //System.out.println(" computers choice is " + cc); //checkcomps choice
       
        // declare and set users choice
        int uc;
        System.out.println( "what is your choice? \n 1 for rock \n 2 for paper \n 3 for scissors \n 4 for lizard \n 5 for spock \n")  ;
        System.out.println( "Please type a number from 1-5 as your selection.\n")  ;

        Scanner input = new Scanner(System.in);
        uc = input.nextInt();
        //System.out.println(" users choice is " + uc ); // check users choice
      
                
        if(cc==uc)//tie
        {
            System.out.println("\nyou have the same choice as the computer. \n It is a tie.\n No points will be awarded to either side.");
        }
        
        else if(uc==1)//if user chooses 1, what are the ways computer can loose--> user wins. If not those, then loose
        {
            if(cc == 4||cc==3)
            {
                System.out.println("\nYou have won the round.\nYou will be awarded one point.");
                uw += 1;
            }
            else
            {
                System.out.println("\nYou have lost the round.\nThe computer will be awarded one point.");
                cw +=1;
            }
        }
        else if(uc==2)//if user chooses 2, what are the ways computer can loose--> user wins. If not those, then loose
        {
            if(cc == 5||cc == 1)
            {
                System.out.println("\nYou have won the round.\nYou will be awarded one point.");
                uw += 1;
            }
            else
            {
                System.out.println("\nYou have lost the round.\nThe computer will be awarded one point.");
                cw +=1;
            }
        }
        else if(uc==3)//if user chooses 3, what are the ways computer can loose--> user wins. If not those, then loose
        {
            if(cc == 4||cc==2)
            {
                System.out.println("\nYou have won the round.\nYou will be awarded one point.");
                uw += 1;
            }
            else
            {
                System.out.println("\nYou have lost the round.\nThe computer will be awarded one point.");
                cw +=1;
            }
        }
        else if(uc==4)//if user chooses 4, what are the ways computer can loose--> user wins. If not those, then loose
        {
            if(cc == 5||cc==2)
            {
                System.out.println("\nYou have won the round.\nYou will be awarded one point.");
                uw += 1;
            }
            else
            {
                System.out.println("\nYou have lost the round.\nThe computer will be awarded one point.");
                cw +=1;
            }
        }
        else if(uc==5)//if user chooses 5, what are the ways computer can loose--> user wins. If not those, then loose
        {
            if(cc == 3||cc==1)
            {
                System.out.println("\nYou have won the round.\nYou will be awarded one point.");
                uw += 1;
            }
            else
            {
                System.out.println("\nYou have lost the round.\nThe computer will be awarded one point.");
                cw +=1;
            }
        }
        System.out.println("The computer chose " + cc); 
        System.out.println("You chose " + uc );
        System.out.println ("\nThe computer's score is " + cw);
        System.out.println ("Your score is " + uw);
        System.out.println ("Lets play again\n");
        
        }// out of for loop
        
        
        System.out.println ("\nThe computer's score is " + cw);
        System.out.println ("Your score is " + uw);
        
        if(uw>cw)
        {
            System.out.println("You win");
        }
        else if(uw<cw)
        {
            System.out.println("You lost.");
        }
        else if(uw==cw)
        {
 	System.out.println ("You tied.");
         }
        }
}
